n = int(input("Enter no of Students:"))
print("Enter marks")

marks=[]
for i in range(n):
    m=float(input())
    marks.append(m)

def selectionSort(marks):
    for i in range(n-1):
        min=i
        for j in range(i+1,n):
            if marks[j]<marks[min]:
                min=j
            if min != i:
                temp = marks[i]
                marks[i] = marks[min]
                marks[min] = temp

selectionSort(marks)

print("Sorted list of marks:")
for i in marks:
    print(i,end=" ")

