n = int(input("Enter no of students : "))
marks=list()
print("Enter marks of students :")

for i in range(n):
    m=float(input())
    marks.append(m)
#bubblesort implementation
def bubbleSort(marks):
    for i in range(n-1):
        for j in range(n-i-1):
            if marks[j]>marks[j+1]:
                temp=marks[j+1]
                marks[j+1]=marks[j]
                marks[j]=temp

bubbleSort(marks)
print("Sorted list of marks: ",end=" ")
print(marks)

print("Top 5 records : ")
top5=marks[-5:]
# top5=top5.reverse()
print(top5)