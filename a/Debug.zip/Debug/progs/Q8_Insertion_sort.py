n = int(input("Enter no of students : "))
marks=list()
print("Enter marks of students :")

for i in range(n):
    m=float(input())
    marks.append(m)

def insertionSort(marks):
    for step in range(1,n):
        key = marks[step]
        j = step-1
        while j>=0 and key<marks[j]:
            marks[j+1]=marks[j]
            j-=1
        marks[j+1]=key

insertionSort(marks)
print("Sorted list of marks: ",end=" ")
print(marks)
