
rows = int(input("Enter no. of rows > "))
cols = int(input("Enter no. of columns > "))  

def addMatrix(matrix1,matrix2):
    res = [[0 for i in range(cols)] for j in range(rows)]
    for i in range(rows):
        for j in range(cols):
            res[i][j]=matrix1[i][j]+matrix2[i][j]
    return res


def multiply(matrix1,matrix2):
    res=[[0 for j in range(cols)] for i in range(rows)]
    for i in range(len(matrix1)):
        for j in range(len(matrix2[0])):
            for k in range(len(matrix2)):
                res[i][j] += matrix1[i][k] * matrix2[k][j]
    return res


#------matrix1
matrix1 = []
print("Enter values for Matrix1 row-wise : ")
for i in range(rows):
    a=[]
    for j in range(cols):
      a.append(int(input()))
    matrix1.append(a)

#------matrix2
matrix2 = []
print("Enter values for Matrix2 row-wise : ")
for i in range(rows):
    a=[]
    for j in range(cols):
      a.append(int(input()))
    matrix2.append(a)
    


#----print addition-----
sum = addMatrix(matrix1,matrix2)
print("Addition :")
for i in range(rows):
    for j in range(cols):
        print(sum[i][j],end=" ")
    print()

#----print multiplication----
mul = multiply(matrix1,matrix2)
print("Multiplication:")
for i in range(rows):
    for j in range(cols):
        print(mul[i][j],end=" ")
    print()

#-----trannspose
print("Tranpose of matrix1:")
for i in range(rows):
    for j in range(cols):
        print(matrix1[j][i],end=" ")
    print()

