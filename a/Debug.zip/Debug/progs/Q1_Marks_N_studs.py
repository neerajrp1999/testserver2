marks=[99,12,0,34,50,0,90,88,0,44]

avg=sum(marks)/len(marks)
print("Average marks of the class : ",avg,end="\n")

high = max(marks)
low = min(marks)
print("Highest score = ",high,"\nLowest score",low)

count=0

for i in marks:
    if i==0:
        count+=1
print("Total absent students for exam:",count)

max = 0
res = marks[0]
for i in marks:
    freq = marks.count(i)
    if freq>max:
        max=freq
        res=i

print("Most frequent number: ",res)
