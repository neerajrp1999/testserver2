
s = input("Enter a String: ")
word_list = s.split()
max = max(word_list,key=len)
print("Longest word in the string is : ",max)


ch = input("Enter a character > ")
lst=list(s)
freq = lst.count(ch)

print("Frequency = ",freq)

rev = s [::-1]#it is called as python slicing and the colon indicates as start point to end point and jumping from the index
if rev==s:
    
    print("String is a palindrome")
else:
    print("Not a palindrome")
    #print (s.find(" om"))