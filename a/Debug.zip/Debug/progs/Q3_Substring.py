s = input("Enter a string : ")
word = input("Enter a word to be searched : ")
idx = s.index(word)
print("First occurence of "+word+" at "+str(idx))

word_list = s.split()
count=dict()
for word in word_list:
    if word in count:
        count[word]+=1
    else:
        count[word]=1

print(count)

rev = s[::-1]
if rev==s:
    print("Palindrome")
else:
    print("Not Palindrome")
